; ∀ (x : BitVec wa) (x1 : BitVec wb), wa < wb → wb < wt →
;   ofBool (zeroExtend wt x1 <ₛ zeroExtend wt x) = ofBool (x1 <ᵤ zeroExtend wb x)
; From: different_size_zext_zext_slt_thm (x : BitVec 4) (x_1 : BitVec 7), concrete widths 4 < 7 < 25
(set-logic ALL)
(declare-const wa Int)
(declare-const wb Int)
(declare-const wt Int)
(declare-const x  (_ BitVec wa))
(declare-const x1 (_ BitVec wb))
(assert (< wa wb))
(assert (< wb wt))
(assert (not (=
  (ite (bvslt (pzero_extend (- wt wb) x1) (pzero_extend (- wt wa) x)) (int_to_pbv 1 1) (int_to_pbv 1 0))
  (ite (bvult x1 (pzero_extend (- wb wa) x))                           (int_to_pbv 1 1) (int_to_pbv 1 0))
)))
(check-sat)
