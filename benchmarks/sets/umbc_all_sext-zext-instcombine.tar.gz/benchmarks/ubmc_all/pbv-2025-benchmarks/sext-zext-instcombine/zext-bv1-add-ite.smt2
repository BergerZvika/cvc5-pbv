; ∀ (c : BitVec 1) (x : BitVec wt) (wt : Int), 1 < wt →
;   zeroExtend wt c + x = ite(c = 1, x + 1, x)
; (zext(0)=0; 0+x=x; zext(1)=1; 1+x=x+1)
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(declare-const x (_ BitVec wt))
(assert (< 1 wt))
(assert (not (=
  (bvadd (pzero_extend (- wt 1) c) x)
  (ite (= c (int_to_pbv 1 1)) (bvadd x (int_to_pbv wt 1)) x)
)))
(check-sat)
