; ∀ (x y : BitVec wa) (wt : Int), wa < wt →
;   ofBool (signExtend wt x >ₛ signExtend wt y) = ofBool (x >ₛ y)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(declare-const y (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (ite (bvsgt (psign_extend (- wt wa) x) (psign_extend (- wt wa) y)) (int_to_pbv 1 1) (int_to_pbv 1 0))
  (ite (bvsgt x y) (int_to_pbv 1 1) (int_to_pbv 1 0))
)))
(check-sat)
