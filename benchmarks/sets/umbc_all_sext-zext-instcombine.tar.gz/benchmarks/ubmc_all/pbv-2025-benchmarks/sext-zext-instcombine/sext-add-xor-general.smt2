; t0_thm (combined form)
; ∀ (x : BitVec wt) (c : BitVec 1) (wt : Int), 1 < wt →
;   signExtend wt c + x ^^^ signExtend wt c = ite(c = 1, 0 - x, x)
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(declare-const x (_ BitVec wt))
(assert (< 1 wt))
(assert (not (=
  (bvxor (bvadd (psign_extend (- wt 1) c) x) (psign_extend (- wt 1) c))
  (ite (= c (int_to_pbv 1 1)) (bvsub (int_to_pbv wt 0) x) x)
)))
(check-sat)
