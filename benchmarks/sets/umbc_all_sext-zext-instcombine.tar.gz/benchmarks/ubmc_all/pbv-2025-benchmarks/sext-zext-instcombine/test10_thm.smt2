(set-logic QF_BV)
(declare-const w1 Int) ; 16
(declare-const w2 Int) ; 32
(declare-const x (_ BitVec w1))
(assert (<= w1 w2))
(assert (= (pextract 0 (- w1 1) (psign_extend w2 x)) x))
(check-sat)


; ∀ (x : BitVec 16), truncate 16 (signExtend 32 x) = x
