; ∀ (c : BitVec 1) (x : BitVec wt) (wt : Int), 1 < wt →
;   zeroExtend wt c * x = signExtend wt c &&& x
; (c=0: 0*x=0=0&&&x; c=1: 1*x=x=-1&&&x=x)
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(declare-const x (_ BitVec wt))
(assert (< 1 wt))
(assert (not (=
  (bvmul (pzero_extend (- wt 1) c) x)
  (bvand (psign_extend (- wt 1) c) x)
)))
(check-sat)
