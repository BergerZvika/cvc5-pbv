; ∀ (x : BitVec wa) (wt : Int), wa < wt →
;   zeroExtend wt (truncate wa (zeroExtend wt x)) = zeroExtend wt x
; (trunc(zext(x))=x, then zext(x) again = zext(x))
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (pzero_extend (- wt wa) (pextract 0 (- wa 1) (pzero_extend (- wt wa) x)))
  (pzero_extend (- wt wa) x)
)))
(check-sat)
