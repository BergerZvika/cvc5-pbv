(set-logic QF_BV)
(declare-const w1 Int) ; 8
(declare-const w2 Int) ; 32
(declare-const x (_ BitVec w2))
(declare-const y (_ BitVec w2))
(assert (<= w1 w2))
(assert (not (= (pzero_extend (- w2 w1) (bvor (pextract 0 (- w1 1) y) (pextract 0 (- w1 1) x))) (bvand (bvor y x) (pzero_extend (- w2 w1) (int_to_pbv w1 -1))))))
(check-sat)

; ∀ (x x_1 : BitVec 32), zeroExtend 32 (truncate 8 x_1 ||| truncate 8 x) = (x_1 ||| x) &&& 255#32
