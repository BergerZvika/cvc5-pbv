; forall (a b c : BitVec wa) ->
;   ofBool (a ^^^ b == a ^^^ c) = ofBool (b == c)
; From: xor_cancel_in_eq_thm: XOR is cancellative in equality
(set-logic ALL)
(declare-const wa Int)
(declare-const a  (_ BitVec wa))
(declare-const b  (_ BitVec wa))
(declare-const c  (_ BitVec wa))
(assert (not (=
  (ite (= (bvxor a b) (bvxor a c)) (int_to_pbv 1 1) (int_to_pbv 1 0))
  (ite (= b c)                      (int_to_pbv 1 1) (int_to_pbv 1 0))
)))
(check-sat)
