; ∀ (a b c : BitVec w) (k : Int), w < k →
;   zeroExtend k (ofBool (a <ₛ b)) &&& zeroExtend k (ofBool (b <ₛ c))
;   = zeroExtend k (ofBool (a <ₛ b) &&& ofBool (b <ₛ c))
; From: fold_and_zext_icmp_thm (x x_1 x_2 : BitVec 64), concrete k=8
(set-logic ALL)
(declare-const w Int)
(declare-const k Int)
(declare-const a (_ BitVec w))
(declare-const b (_ BitVec w))
(declare-const c (_ BitVec w))
(assert (< w k))
(assert (not (=
  (bvand (pzero_extend (- k 1) (ite (bvslt a b) (int_to_pbv 1 1) (int_to_pbv 1 0)))
         (pzero_extend (- k 1) (ite (bvslt b c) (int_to_pbv 1 1) (int_to_pbv 1 0))))
  (pzero_extend (- k 1) (bvand (ite (bvslt a b) (int_to_pbv 1 1) (int_to_pbv 1 0))
                                (ite (bvslt b c) (int_to_pbv 1 1) (int_to_pbv 1 0))))
)))
(check-sat)
