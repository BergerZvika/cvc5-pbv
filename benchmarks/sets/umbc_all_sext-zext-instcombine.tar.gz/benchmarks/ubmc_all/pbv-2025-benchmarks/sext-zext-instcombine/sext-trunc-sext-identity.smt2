; ∀ (x : BitVec wa) (wt : Int), wa < wt →
;   signExtend wt (truncate wa (signExtend wt x)) = signExtend wt x
; (trunc(sext(x))=x, then sext(x) again = sext(x))
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (psign_extend (- wt wa) (pextract 0 (- wa 1) (psign_extend (- wt wa) x)))
  (psign_extend (- wt wa) x)
)))
(check-sat)
