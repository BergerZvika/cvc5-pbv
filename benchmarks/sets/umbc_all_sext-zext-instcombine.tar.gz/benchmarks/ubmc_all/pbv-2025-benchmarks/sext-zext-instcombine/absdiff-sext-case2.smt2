; absdiff_thm.extracted_1._2 (generalized)
; ∀ (a b : BitVec wt) (wt : Int), 1 < wt → ¬(a <ᵤ b) →
;   (signExtend wt (ofBool (a <ᵤ b)) ^^^ (a - b)) - signExtend wt (ofBool (a <ᵤ b))
;   = a - b
; (sext(0)=0; (0 ^^^ (a-b)) - 0 = a-b)
(set-logic ALL)
(declare-const wt Int)
(declare-const a (_ BitVec wt))
(declare-const b (_ BitVec wt))
(assert (< 1 wt))
(assert (not (bvult a b)))
(assert (not (=
  (bvsub
    (bvxor (psign_extend (- wt 1) (ite (bvult a b) (int_to_pbv 1 1) (int_to_pbv 1 0)))
           (bvsub a b))
    (psign_extend (- wt 1) (ite (bvult a b) (int_to_pbv 1 1) (int_to_pbv 1 0))))
  (bvsub a b)
)))
(check-sat)
