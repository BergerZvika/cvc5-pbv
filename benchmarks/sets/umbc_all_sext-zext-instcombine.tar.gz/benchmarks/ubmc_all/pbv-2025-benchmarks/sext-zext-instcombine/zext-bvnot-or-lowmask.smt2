; ∀ (x : BitVec wa) (wt : Int), wa < wt →
;   zeroExtend wt (bvnot x) ||| zeroExtend wt x = lowmask
; (bvnot(x) ||| x = allones in wa bits; zext gives lowmask)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (bvor (pzero_extend (- wt wa) (bvnot x)) (pzero_extend (- wt wa) x))
  (pzero_extend (- wt wa) (bvnot (int_to_pbv wa 0)))
)))
(check-sat)
