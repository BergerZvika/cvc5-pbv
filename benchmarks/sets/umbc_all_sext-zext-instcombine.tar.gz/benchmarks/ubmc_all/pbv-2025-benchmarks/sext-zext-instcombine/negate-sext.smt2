; ∀ (x : BitVec 1) (x1 : BitVec wa), 1 ≤ wa →
;   x1 - signExtend wa x = x1 + zeroExtend wa x
; From: negate_sext_thm (x : BitVec 1) (x_1 : BitVec 8), concrete wa=8
(set-logic ALL)
(declare-const wa Int)
(declare-const x  (_ BitVec 1))
(declare-const x1 (_ BitVec wa))
(assert (<= 1 wa))
(assert (not (=
  (bvsub x1 (psign_extend (- wa 1) x))
  (bvadd x1 (pzero_extend (- wa 1) x))
)))
(check-sat)
