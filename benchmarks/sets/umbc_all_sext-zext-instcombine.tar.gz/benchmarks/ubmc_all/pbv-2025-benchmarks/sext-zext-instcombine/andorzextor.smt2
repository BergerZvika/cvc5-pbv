; ∀ (x c d : BitVec wa) (wt : Int), wa < wt →
;   zeroExtend wt (x &&& c ||| d) = zeroExtend wt x &&& zeroExtend wt c ||| zeroExtend wt d
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(declare-const c (_ BitVec wa))
(declare-const d (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (pzero_extend (- wt wa) (bvor (bvand x c) d))
  (bvor (bvand (pzero_extend (- wt wa) x) (pzero_extend (- wt wa) c)) (pzero_extend (- wt wa) d))
)))
(check-sat)
