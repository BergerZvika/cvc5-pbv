; ∀ (c : BitVec 1) (x y : BitVec wt) (wt : Int), 1 < wt →
;   x &&& signExtend wt c ||| y &&& bvnot(signExtend wt c)
;   = ite(c = 1, x, y)
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(declare-const x (_ BitVec wt))
(declare-const y (_ BitVec wt))
(assert (< 1 wt))
(assert (not (=
  (bvor (bvand x (psign_extend (- wt 1) c)) (bvand y (bvnot (psign_extend (- wt 1) c))))
  (ite (= c (int_to_pbv 1 1)) x y)
)))
(check-sat)
