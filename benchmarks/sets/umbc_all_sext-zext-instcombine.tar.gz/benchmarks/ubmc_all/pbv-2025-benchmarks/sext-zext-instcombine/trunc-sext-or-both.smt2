; ∀ (x y : BitVec wa) (wt : Int), wa < wt →
;   truncate wa (signExtend wt x ||| signExtend wt y) = x ||| y
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(declare-const y (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (pextract 0 (- wa 1) (bvor (psign_extend (- wt wa) x) (psign_extend (- wt wa) y)))
  (bvor x y)
)))
(check-sat)
