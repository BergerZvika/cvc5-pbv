; forall (a b : BitVec wa) (wt : Int), 1 <= wt ->
;   trunc 1 (zeroExtend wt (a <s b) &&& zeroExtend wt (b <s a)) = 0
; From: trunc1_icmp_antisym_thm: a<b and b<a cannot both be true (antisymmetry)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const a  (_ BitVec wa))
(declare-const b  (_ BitVec wa))
(assert (<= 1 wt))
(assert (not (=
  (pextract 0 0
    (bvand
      (pzero_extend (- wt 1) (ite (bvslt a b) (int_to_pbv 1 1) (int_to_pbv 1 0)))
      (pzero_extend (- wt 1) (ite (bvslt b a) (int_to_pbv 1 1) (int_to_pbv 1 0)))))
  (int_to_pbv 1 0)
)))
(check-sat)
