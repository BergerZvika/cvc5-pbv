; ∀ (a b : BitVec w) (wt : Int), w < wt →
;   zeroExtend wt (ofBool (a <ᵤ b)) ||| zeroExtend wt (ofBool (b <=ᵤ a)) = 1
; (either a <u b or b <=u a; one must hold)
(set-logic ALL)
(declare-const w Int)
(declare-const wt Int)
(declare-const a (_ BitVec w))
(declare-const b (_ BitVec w))
(assert (< w wt))
(assert (not (=
  (bvor (pzero_extend (- wt 1) (ite (bvult a b) (int_to_pbv 1 1) (int_to_pbv 1 0)))
        (pzero_extend (- wt 1) (ite (bvule b a) (int_to_pbv 1 1) (int_to_pbv 1 0))))
  (int_to_pbv wt 1)
)))
(check-sat)
