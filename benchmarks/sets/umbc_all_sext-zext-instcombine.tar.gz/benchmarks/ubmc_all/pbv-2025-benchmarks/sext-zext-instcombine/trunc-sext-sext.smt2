; forall (x : BitVec wa), wa <= wm -> wm <= wt ->
;   truncate wm (signExtend wt x) = signExtend wm x
; From: trunc_sext_sext_thm: truncating a sext to intermediate width = sext to that width
(set-logic ALL)
(declare-const wa Int)
(declare-const wm Int)
(declare-const wt Int)
(declare-const x  (_ BitVec wa))
(assert (<= wa wm))
(assert (<= wm wt))
(assert (not (=
  (pextract 0 (- wm 1) (psign_extend (- wt wa) x))
  (psign_extend (- wm wa) x)
)))
(check-sat)
