; absdiff_thm.extracted_1._1 (generalized)
; ∀ (a b : BitVec wt) (wt : Int), 1 < wt → a <ᵤ b →
;   (signExtend wt (ofBool (a <ᵤ b)) ^^^ (a - b)) - signExtend wt (ofBool (a <ᵤ b))
;   = b - a
; (sext(1)=-1; (-1 ^^^ (a-b)) - (-1) = ~(a-b)+1 = -(a-b) = b-a)
(set-logic ALL)
(declare-const wt Int)
(declare-const a (_ BitVec wt))
(declare-const b (_ BitVec wt))
(assert (< 1 wt))
(assert (bvult a b))
(assert (not (=
  (bvsub
    (bvxor (psign_extend (- wt 1) (ite (bvult a b) (int_to_pbv 1 1) (int_to_pbv 1 0)))
           (bvsub a b))
    (psign_extend (- wt 1) (ite (bvult a b) (int_to_pbv 1 1) (int_to_pbv 1 0))))
  (bvsub b a)
)))
(check-sat)
