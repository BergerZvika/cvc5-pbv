; forall (x : BitVec wa) (y : BitVec wt), wa < wt ->
;   signExtend wt x + y = y + signExtend wt x
; From: sext_add_comm_thm: addition is commutative (via sext)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x  (_ BitVec wa))
(declare-const y  (_ BitVec wt))
(assert (< wa wt))
(assert (not (=
  (bvadd (psign_extend (- wt wa) x) y)
  (bvadd y (psign_extend (- wt wa) x))
)))
(check-sat)
