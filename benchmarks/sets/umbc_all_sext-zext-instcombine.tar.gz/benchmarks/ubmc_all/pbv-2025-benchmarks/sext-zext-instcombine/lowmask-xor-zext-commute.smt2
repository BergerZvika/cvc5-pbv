; lowmask_xor_zext_commute_thm
; ∀ (x : BitVec wa) (y : BitVec wt), wa < wt →
;   (y ^^^ zeroExtend wt x) &&& lowmask(wa,wt)
;   = zeroExtend wt (x ^^^ truncate wa y)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(declare-const y (_ BitVec wt))
(assert (< wa wt))
(assert (not (=
  (bvand (bvxor y (pzero_extend (- wt wa) x)) (pzero_extend (- wt wa) (bvnot (int_to_pbv wa 0))))
  (pzero_extend (- wt wa) (bvxor x (pextract 0 (- wa 1) y)))
)))
(check-sat)
