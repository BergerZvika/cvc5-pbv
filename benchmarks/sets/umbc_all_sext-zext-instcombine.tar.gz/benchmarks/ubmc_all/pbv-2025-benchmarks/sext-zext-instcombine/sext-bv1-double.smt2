; ∀ (c : BitVec 1) (wt : Int), 1 < wt →
;   signExtend wt c + signExtend wt c = 0 - (zeroExtend wt c + zeroExtend wt c)
; (2*sext(c): c=0→0=-(0+0); c=1→-2=-(1+1))
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(assert (< 1 wt))
(assert (not (=
  (bvadd (psign_extend (- wt 1) c) (psign_extend (- wt 1) c))
  (bvsub (int_to_pbv wt 0) (bvadd (pzero_extend (- wt 1) c) (pzero_extend (- wt 1) c)))
)))
(check-sat)
