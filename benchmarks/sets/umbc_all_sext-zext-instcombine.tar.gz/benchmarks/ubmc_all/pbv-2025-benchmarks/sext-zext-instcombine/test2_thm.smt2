(set-logic QF_BV)
(declare-const w1 Int) ; 8
(declare-const w2 Int) ; 16
(declare-const w3 Int) ; 32
(declare-const w4 Int) ; 64
(declare-const x (_ BitVec w1))
(assert (<= w1 w2))
(assert (<= w2 w3))
(assert (<= w3 w4))
(assert (not (= (pzero_extend (- w4 w3) (pzero_extend (- w3 w2) (pzero_extend (- w2 w1) x))) (pzero_extend (- w4 w1) x))))
(check-sat)

; ∀ (x : BitVec 8), zeroExtend 64 (zeroExtend 32 (zeroExtend 16 x)) = zeroExtend 64 x
