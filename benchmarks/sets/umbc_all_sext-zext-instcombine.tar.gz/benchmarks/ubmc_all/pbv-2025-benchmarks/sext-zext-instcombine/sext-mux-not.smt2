; ∀ (c : BitVec 1) (x y : BitVec wt) (wt : Int), 1 < wt →
;   bvnot(signExtend wt c) &&& x ||| signExtend wt c &&& y
;   = ite(c = 1, y, x)
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(declare-const x (_ BitVec wt))
(declare-const y (_ BitVec wt))
(assert (< 1 wt))
(assert (not (=
  (bvor (bvand (bvnot (psign_extend (- wt 1) c)) x) (bvand (psign_extend (- wt 1) c) y))
  (ite (= c (int_to_pbv 1 1)) y x)
)))
(check-sat)
