; ∀ (x : BitVec wt) (wa wm : Int), wa < wm → wm < wt →
;   truncate wa (signExtend wt (truncate wm x)) = truncate wa x
; (trunc(wm) keeps low wm bits; sext extends from wm to wt; trunc(wa) takes low wa bits;
;  net result: same as just taking low wa bits of x)
(set-logic ALL)
(declare-const wa Int)
(declare-const wm Int)
(declare-const wt Int)
(declare-const x (_ BitVec wt))
(assert (< wa wm))
(assert (< wm wt))
(assert (not (=
  (pextract 0 (- wa 1) (psign_extend (- wt wm) (pextract 0 (- wm 1) x)))
  (pextract 0 (- wa 1) x)
)))
(check-sat)
