; and_sext_multiuse_thm (distributive law)
; ∀ (c : BitVec 1) (x y : BitVec wt) (wt : Int), 1 < wt →
;   signExtend wt c &&& x + signExtend wt c &&& y
;   = signExtend wt c &&& (x + y)
; (sext(c) for c:BitVec 1 is either 0 or -1, both distribute over +)
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(declare-const x (_ BitVec wt))
(declare-const y (_ BitVec wt))
(assert (< 1 wt))
(assert (not (=
  (bvadd (bvand (psign_extend (- wt 1) c) x) (bvand (psign_extend (- wt 1) c) y))
  (bvand (psign_extend (- wt 1) c) (bvadd x y))
)))
(check-sat)
