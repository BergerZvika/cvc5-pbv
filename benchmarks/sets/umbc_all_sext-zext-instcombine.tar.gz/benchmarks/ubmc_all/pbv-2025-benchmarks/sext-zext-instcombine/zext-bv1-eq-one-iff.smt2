; ∀ (c : BitVec 1) (wt : Int), 1 < wt →
;   ofBool (zeroExtend wt c == 1) = c
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(assert (< 1 wt))
(assert (not (=
  (ite (= (pzero_extend (- wt 1) c) (int_to_pbv wt 1)) (int_to_pbv 1 1) (int_to_pbv 1 0))
  c
)))
(check-sat)
