; forall (x y : BitVec wa), wa < wt ->
;   ofBool (zeroExtend wt x >=s zeroExtend wt y) = ofBool (x >=u y)
; From: zext_zext_sge_same_thm: signed >= of zero-extends equals unsigned >=
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x  (_ BitVec wa))
(declare-const y  (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (ite (bvsge (pzero_extend (- wt wa) x) (pzero_extend (- wt wa) y)) (int_to_pbv 1 1) (int_to_pbv 1 0))
  (ite (bvuge x y)                                                      (int_to_pbv 1 1) (int_to_pbv 1 0))
)))
(check-sat)
