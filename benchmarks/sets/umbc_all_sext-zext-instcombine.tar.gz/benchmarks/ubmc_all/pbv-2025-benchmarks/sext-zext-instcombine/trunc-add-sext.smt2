; ∀ (x : BitVec wa) (y : BitVec wt), wa < wt →
;   truncate wa (signExtend wt x + y) = x + truncate wa y
; (same as trunc-add-zext but for sext; low bits of sext = x)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(declare-const y (_ BitVec wt))
(assert (< wa wt))
(assert (not (=
  (pextract 0 (- wa 1) (bvadd (psign_extend (- wt wa) x) y))
  (bvadd x (pextract 0 (- wa 1) y))
)))
(check-sat)
