; ∀ (x y : BitVec wa) (wt : Int), wa < wt →
;   truncate wa (signExtend wt x + bvnot (signExtend wt y)) = x + bvnot y
; (bvnot distributes through sext for low bits; x + bvnot(y) = x - y - 1)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(declare-const y (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (pextract 0 (- wa 1) (bvadd (psign_extend (- wt wa) x) (bvnot (psign_extend (- wt wa) y))))
  (bvadd x (bvnot y))
)))
(check-sat)
