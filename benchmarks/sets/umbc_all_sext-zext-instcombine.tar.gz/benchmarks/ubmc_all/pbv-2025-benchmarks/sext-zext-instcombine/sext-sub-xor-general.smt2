; sext_xor_sub_2_thm (combined form)
; ∀ (x : BitVec wt) (c : BitVec 1) (wt : Int), 1 < wt →
;   signExtend wt c - (x ^^^ signExtend wt c) = ite(c = 1, x, 0 - x)
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(declare-const x (_ BitVec wt))
(assert (< 1 wt))
(assert (not (=
  (bvsub (psign_extend (- wt 1) c) (bvxor x (psign_extend (- wt 1) c)))
  (ite (= c (int_to_pbv 1 1)) x (bvsub (int_to_pbv wt 0) x))
)))
(check-sat)
