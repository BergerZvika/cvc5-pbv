; absdiff1_thm.extracted_1._1 (generalized)
; ∀ (a b : BitVec wt) (wt : Int), 1 < wt → b <ᵤ a →
;   ((a - b) ^^^ signExtend wt (ofBool (b <ᵤ a))) - signExtend wt (ofBool (b <ᵤ a))
;   = b - a
(set-logic ALL)
(declare-const wt Int)
(declare-const a (_ BitVec wt))
(declare-const b (_ BitVec wt))
(assert (< 1 wt))
(assert (bvult b a))
(assert (not (=
  (bvsub
    (bvxor (bvsub a b)
           (psign_extend (- wt 1) (ite (bvult b a) (int_to_pbv 1 1) (int_to_pbv 1 0))))
    (psign_extend (- wt 1) (ite (bvult b a) (int_to_pbv 1 1) (int_to_pbv 1 0))))
  (bvsub b a)
)))
(check-sat)
