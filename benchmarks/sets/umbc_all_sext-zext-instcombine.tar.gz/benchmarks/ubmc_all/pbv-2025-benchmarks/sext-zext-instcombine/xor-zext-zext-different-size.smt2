; ∀ (x : BitVec wb) (y : BitVec wa), wa < wb → wb < wt →
;   zeroExtend wt x ^^^ zeroExtend wt y = zeroExtend wt (x ^^^ zeroExtend wb y)
; Analogous to and_zext_zext and or_zext_zext
(set-logic ALL)
(declare-const wa Int)
(declare-const wb Int)
(declare-const wt Int)
(declare-const x (_ BitVec wb))
(declare-const y (_ BitVec wa))
(assert (< wa wb))
(assert (< wb wt))
(assert (not (=
  (bvxor (pzero_extend (- wt wb) x) (pzero_extend (- wt wa) y))
  (pzero_extend (- wt wb) (bvxor x (pzero_extend (- wb wa) y)))
)))
(check-sat)
