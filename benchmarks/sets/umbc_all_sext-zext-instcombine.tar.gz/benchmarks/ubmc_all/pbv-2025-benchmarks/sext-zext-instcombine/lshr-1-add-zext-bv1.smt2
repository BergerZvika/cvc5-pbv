; lshr_2_add_zext_basic_thm (generalized)
; ∀ (x y : BitVec 1) (wt : Int), 1 < wt →
;   (zeroExtend wt x + zeroExtend wt y) >>> 1 = zeroExtend wt (x &&& y)
; (the carry bit of two 1-bit values equals their AND)
(set-logic ALL)
(declare-const wt Int)
(declare-const x (_ BitVec 1))
(declare-const y (_ BitVec 1))
(assert (< 1 wt))
(assert (not (=
  (bvlshr (bvadd (pzero_extend (- wt 1) x) (pzero_extend (- wt 1) y)) (int_to_pbv wt 1))
  (pzero_extend (- wt 1) (bvand x y))
)))
(check-sat)
