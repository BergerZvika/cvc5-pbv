; ∀ (x y : BitVec wa) (wt : Int), wa < wt →
;   truncate wa (zeroExtend wt x + bvnot (zeroExtend wt y)) = x + bvnot y
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(declare-const y (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (pextract 0 (- wa 1) (bvadd (pzero_extend (- wt wa) x) (bvnot (pzero_extend (- wt wa) y))))
  (bvadd x (bvnot y))
)))
(check-sat)
