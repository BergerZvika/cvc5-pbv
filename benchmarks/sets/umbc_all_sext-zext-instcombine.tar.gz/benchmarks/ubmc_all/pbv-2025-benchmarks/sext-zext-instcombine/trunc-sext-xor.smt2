; forall (x y : BitVec wa), wa <= wt ->
;   truncate wa (signExtend wt x ^^^ signExtend wt y) = x ^^^ y
; From: trunc_sext_xor_thm: xor preserved after sext and trunc
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x  (_ BitVec wa))
(declare-const y  (_ BitVec wa))
(assert (<= wa wt))
(assert (not (=
  (pextract 0 (- wa 1) (bvxor (psign_extend (- wt wa) x) (psign_extend (- wt wa) y)))
  (bvxor x y)
)))
(check-sat)
