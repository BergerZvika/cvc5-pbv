; ∀ (x : BitVec wa) (wt : Int), wa < wt →
;   ofBool (signExtend wt x >=ₛ 0) = ofBool (x >=ₛ 0)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (ite (bvsge (psign_extend (- wt wa) x) (int_to_pbv wt 0)) (int_to_pbv 1 1) (int_to_pbv 1 0))
  (ite (bvsge x (int_to_pbv wa 0)) (int_to_pbv 1 1) (int_to_pbv 1 0))
)))
(check-sat)
