; ∀ (x y : BitVec wa) (wt : Int), wa < wt →
;   ofBool (zeroExtend wt x == zeroExtend wt y) = ofBool (x == y)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(declare-const y (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (ite (= (pzero_extend (- wt wa) x) (pzero_extend (- wt wa) y)) (int_to_pbv 1 1) (int_to_pbv 1 0))
  (ite (= x y) (int_to_pbv 1 1) (int_to_pbv 1 0))
)))
(check-sat)
