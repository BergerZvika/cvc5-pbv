; ∀ (x : BitVec wa) (y : BitVec wt), wa < wt →
;   (signExtend wt x * y) &&& lowmask(wa,wt) = (zeroExtend wt x * y) &&& lowmask(wa,wt)
; (low bits of sext = zext, multiplication low bits depend only on low bits of operands)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(declare-const y (_ BitVec wt))
(assert (< wa wt))
(assert (not (=
  (bvand (bvmul (psign_extend (- wt wa) x) y) (pzero_extend (- wt wa) (bvnot (int_to_pbv wa 0))))
  (bvand (bvmul (pzero_extend (- wt wa) x) y) (pzero_extend (- wt wa) (bvnot (int_to_pbv wa 0))))
)))
(check-sat)
