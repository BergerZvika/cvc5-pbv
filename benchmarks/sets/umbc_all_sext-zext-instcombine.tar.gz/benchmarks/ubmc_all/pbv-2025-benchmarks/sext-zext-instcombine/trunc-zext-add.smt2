; forall (x y : BitVec wa), wa < wt ->
;   truncate wa (zeroExtend wt x + zeroExtend wt y) = x + y
; From: trunc_zext_add_thm: modular addition preserved after zext and trunc
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x  (_ BitVec wa))
(declare-const y  (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (pextract 0 (- wa 1) (bvadd (pzero_extend (- wt wa) x) (pzero_extend (- wt wa) y)))
  (bvadd x y)
)))
(check-sat)
