; ∀ (c : BitVec 1) (x : BitVec wt) (wt : Int), 1 < wt →
;   x - signExtend wt c = ite(c = 1, x + 1, x)
; (x - sext(0) = x - 0 = x; x - sext(1) = x - (-1) = x + 1)
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(declare-const x (_ BitVec wt))
(assert (< 1 wt))
(assert (not (=
  (bvsub x (psign_extend (- wt 1) c))
  (ite (= c (int_to_pbv 1 1)) (bvadd x (int_to_pbv wt 1)) x)
)))
(check-sat)
