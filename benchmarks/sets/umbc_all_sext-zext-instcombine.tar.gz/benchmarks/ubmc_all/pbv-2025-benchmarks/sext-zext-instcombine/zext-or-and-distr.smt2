; ∀ (x y z : BitVec wa) (wt : Int), wa < wt →
;   zeroExtend wt (x ||| (y &&& z)) = zeroExtend wt x ||| (zeroExtend wt y &&& zeroExtend wt z)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(declare-const y (_ BitVec wa))
(declare-const z (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (pzero_extend (- wt wa) (bvor x (bvand y z)))
  (bvor (pzero_extend (- wt wa) x) (bvand (pzero_extend (- wt wa) y) (pzero_extend (- wt wa) z)))
)))
(check-sat)
