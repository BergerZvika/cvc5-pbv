; ∀ (x : BitVec wa) (wt : Int), wa < wt →
;   truncate wa (bvnot (signExtend wt x)) = bvnot x
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (pextract 0 (- wa 1) (bvnot (psign_extend (- wt wa) x)))
  (bvnot x)
)))
(check-sat)
