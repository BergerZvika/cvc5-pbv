; ∀ (x y : BitVec wa) (wt : Int), wa < wt →
;   zeroExtend wt (x ||| y) = zeroExtend wt x ||| zeroExtend wt y
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(declare-const y (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (pzero_extend (- wt wa) (bvor x y))
  (bvor (pzero_extend (- wt wa) x) (pzero_extend (- wt wa) y))
)))
(check-sat)
