; ∀ (c : BitVec wa) (x : BitVec wt) (wt wa : Int), wa < wt →
;   zeroExtend wt c ^^^ x ^^^ zeroExtend wt c = x
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const c (_ BitVec wa))
(declare-const x (_ BitVec wt))
(assert (< wa wt))
(assert (not (=
  (bvxor (bvxor (pzero_extend (- wt wa) c) x) (pzero_extend (- wt wa) c))
  x
)))
(check-sat)
