(set-logic QF_BV)
(declare-const w1 Int) ; 8
(declare-const w2 Int) ; 16
(declare-const w3 Int) ; 32
(declare-const x (_ BitVec w1))
(assert (<= w1 w2))
(assert (<= w2 w3))
(assert (= (pextract 0 (- w2 1) (psign_extend w3 x)) (psign_extend w2 x)))
(check-sat)


; ∀ (x : BitVec 8), truncate 16 (signExtend 32 x) = signExtend 16 x 

