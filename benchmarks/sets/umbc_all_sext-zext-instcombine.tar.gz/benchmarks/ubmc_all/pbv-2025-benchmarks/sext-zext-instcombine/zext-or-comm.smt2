; forall (x : BitVec wa) (y : BitVec wt), wa < wt ->
;   zeroExtend wt x ||| y = y ||| zeroExtend wt x
; From: zext_or_comm_thm: OR is commutative (via zext)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x  (_ BitVec wa))
(declare-const y  (_ BitVec wt))
(assert (< wa wt))
(assert (not (=
  (bvor (pzero_extend (- wt wa) x) y)
  (bvor y (pzero_extend (- wt wa) x))
)))
(check-sat)
