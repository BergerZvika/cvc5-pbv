; ∀ (c : BitVec 1) (wt : Int), 1 < wt →
;   ofBool (zeroExtend wt c <ₛ signExtend wt c + 1) = bvnot c
; (c=0: 0 <s 1 = true → 1 = bvnot(0) ✓; c=1: 1 <s 0 = false → 0 = bvnot(1) ✓)
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(assert (< 1 wt))
(assert (not (=
  (ite (bvslt (pzero_extend (- wt 1) c) (bvadd (psign_extend (- wt 1) c) (int_to_pbv wt 1))) (int_to_pbv 1 1) (int_to_pbv 1 0))
  (bvnot c)
)))
(check-sat)
