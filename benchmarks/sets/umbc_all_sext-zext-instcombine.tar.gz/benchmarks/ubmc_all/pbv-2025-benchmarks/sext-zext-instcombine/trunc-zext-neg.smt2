; ∀ (x : BitVec wa) (wt : Int), wa < wt →
;   truncate wa (bvneg (zeroExtend wt x)) = bvneg x
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (pextract 0 (- wa 1) (bvneg (pzero_extend (- wt wa) x)))
  (bvneg x)
)))
(check-sat)
