; ∀ (x : BitVec wa) (wt : Int), wa < wt →
;   truncate wa (bvnot (zeroExtend wt x)) = bvnot x
; (bvnot(zext(x)) = bvnot in high bits too, but trunc discards them)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (pextract 0 (- wa 1) (bvnot (pzero_extend (- wt wa) x)))
  (bvnot x)
)))
(check-sat)
