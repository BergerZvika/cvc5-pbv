; ∀ (x : BitVec wa) (y : BitVec wt), wa < wt →
;   truncate wa (signExtend wt x ||| y) = x ||| truncate wa y
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(declare-const y (_ BitVec wt))
(assert (< wa wt))
(assert (not (=
  (pextract 0 (- wa 1) (bvor (psign_extend (- wt wa) x) y))
  (bvor x (pextract 0 (- wa 1) y))
)))
(check-sat)
