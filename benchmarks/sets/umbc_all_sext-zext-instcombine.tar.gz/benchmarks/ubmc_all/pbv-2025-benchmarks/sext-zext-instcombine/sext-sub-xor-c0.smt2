; sext_xor_sub_2_thm.extracted_1._2
; ∀ (x : BitVec wt) (c : BitVec 1) (wt : Int), 1 < wt → c ≠ 1 →
;   signExtend wt c - (x ^^^ signExtend wt c) = 0 - x
; (sext(0) = 0; 0 - (x ^^^ 0) = 0 - x = -x)
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(declare-const x (_ BitVec wt))
(assert (< 1 wt))
(assert (not (= c (int_to_pbv 1 1))))
(assert (not (=
  (bvsub (psign_extend (- wt 1) c) (bvxor x (psign_extend (- wt 1) c)))
  (bvsub (int_to_pbv wt 0) x)
)))
(check-sat)
