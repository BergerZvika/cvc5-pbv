; forall (x x1 : BitVec 1) (wt : Int), 1 < wt ->
;   ofBool (zeroExtend wt x1 + signExtend wt x <s -1) = 0
; From: zext_sext_add_slt_neg1_false_thm: sum>=-1 always, so sum<s-1 is never true
(set-logic ALL)
(declare-const wt Int)
(declare-const x  (_ BitVec 1))
(declare-const x1 (_ BitVec 1))
(assert (< 1 wt))
(assert (not (=
  (ite (bvslt (bvadd (pzero_extend (- wt 1) x1) (psign_extend (- wt 1) x)) (bvnot (int_to_pbv wt 0))) (int_to_pbv 1 1) (int_to_pbv 1 0))
  (int_to_pbv 1 0)
)))
(check-sat)
