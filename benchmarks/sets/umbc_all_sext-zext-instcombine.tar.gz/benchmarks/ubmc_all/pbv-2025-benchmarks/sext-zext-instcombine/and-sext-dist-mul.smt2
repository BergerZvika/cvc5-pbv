; ∀ (c : BitVec 1) (x y : BitVec wt) (wt : Int), 1 < wt →
;   signExtend wt c &&& (x * y) = (signExtend wt c &&& x) * y
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(declare-const x (_ BitVec wt))
(declare-const y (_ BitVec wt))
(assert (< 1 wt))
(assert (not (=
  (bvand (psign_extend (- wt 1) c) (bvmul x y))
  (bvmul (bvand (psign_extend (- wt 1) c) x) y)
)))
(check-sat)
