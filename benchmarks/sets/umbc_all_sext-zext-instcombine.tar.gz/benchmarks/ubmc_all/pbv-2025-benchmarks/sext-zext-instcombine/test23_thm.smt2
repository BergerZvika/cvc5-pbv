(set-logic QF_BV)
(declare-const w1 Int) ; 16
(declare-const w2 Int) ; 32
(declare-const x (_ BitVec w2))
(assert (<= w1 w2))
(assert (= (pzero_extend w2 (pextract 0 (- w1 1) x)) (bvand x (pzero_extend w2 (int_to_pbv w1 -1)))))
(check-sat)

;∀ (x : BitVec 32), zeroExtend 32 (truncate 16 x) = x &&& 65535#32
