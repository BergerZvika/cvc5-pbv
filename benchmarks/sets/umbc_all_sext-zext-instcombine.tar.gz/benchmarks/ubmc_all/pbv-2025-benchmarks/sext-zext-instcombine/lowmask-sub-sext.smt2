; ∀ (x : BitVec wa) (y : BitVec wt), wa < wt →
;   (y - signExtend wt x) &&& lowmask(wa,wt) = zeroExtend wt (truncate wa y - x)
; (sext and zext agree on low bits; subtraction low bits depend only on low bits of operands)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(declare-const y (_ BitVec wt))
(assert (< wa wt))
(assert (not (=
  (bvand (bvsub y (psign_extend (- wt wa) x)) (pzero_extend (- wt wa) (bvnot (int_to_pbv wa 0))))
  (pzero_extend (- wt wa) (bvsub (pextract 0 (- wa 1) y) x))
)))
(check-sat)
