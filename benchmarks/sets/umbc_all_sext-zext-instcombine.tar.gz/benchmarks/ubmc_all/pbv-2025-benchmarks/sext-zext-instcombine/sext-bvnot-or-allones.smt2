; ∀ (x : BitVec wa) (wt : Int), wa < wt →
;   signExtend wt (bvnot x) ||| signExtend wt x = bvnot (int_to_pbv wt 0)
; (bvnot(y) ||| y = allones)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (bvor (psign_extend (- wt wa) (bvnot x)) (psign_extend (- wt wa) x))
  (bvnot (int_to_pbv wt 0))
)))
(check-sat)
