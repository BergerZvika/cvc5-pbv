; ∀ (c : BitVec 1) (wt : Int), 1 < wt →
;   zeroExtend wt c &&& signExtend wt c = zeroExtend wt c
; (c=0: 0&&&0=0; c=1: 1&&&-1=1)
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(assert (< 1 wt))
(assert (not (=
  (bvand (pzero_extend (- wt 1) c) (psign_extend (- wt 1) c))
  (pzero_extend (- wt 1) c)
)))
(check-sat)
