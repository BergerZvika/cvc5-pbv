; ∀ (c1 c2 c3 : BitVec 1) (w : Int), 1 < w →
;   zeroExtend w c1 &&& zeroExtend w c2 &&& zeroExtend w c3
;   = zeroExtend w (c1 &&& c2 &&& c3)
(set-logic ALL)
(declare-const w Int)
(declare-const c1 (_ BitVec 1))
(declare-const c2 (_ BitVec 1))
(declare-const c3 (_ BitVec 1))
(assert (< 1 w))
(assert (not (=
  (bvand (bvand (pzero_extend (- w 1) c1) (pzero_extend (- w 1) c2)) (pzero_extend (- w 1) c3))
  (pzero_extend (- w 1) (bvand (bvand c1 c2) c3))
)))
(check-sat)
