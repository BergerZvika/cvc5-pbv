; ∀ (x y : BitVec wa) (wt : Int), wa < wt →
;   signExtend wt x &&& signExtend wt y &&& lowmask
;   = zeroExtend wt x &&& zeroExtend wt y &&& lowmask
; where lowmask = 2^wa - 1 (ones in low wa bits)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(declare-const y (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (bvand (bvand (psign_extend (- wt wa) x) (psign_extend (- wt wa) y))
         (pzero_extend (- wt wa) (bvnot (int_to_pbv wa 0))))
  (bvand (bvand (pzero_extend (- wt wa) x) (pzero_extend (- wt wa) y))
         (pzero_extend (- wt wa) (bvnot (int_to_pbv wa 0))))
)))
(check-sat)
