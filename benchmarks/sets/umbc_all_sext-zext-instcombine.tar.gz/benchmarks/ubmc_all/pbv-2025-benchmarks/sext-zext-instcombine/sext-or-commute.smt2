; ∀ (x y : BitVec wa) (wt : Int), wa < wt →
;   signExtend wt (x ||| y) = signExtend wt x ||| signExtend wt y
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(declare-const y (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (psign_extend (- wt wa) (bvor x y))
  (bvor (psign_extend (- wt wa) x) (psign_extend (- wt wa) y))
)))
(check-sat)
