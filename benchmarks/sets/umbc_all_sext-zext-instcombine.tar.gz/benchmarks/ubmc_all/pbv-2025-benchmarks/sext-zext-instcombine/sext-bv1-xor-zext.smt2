; ∀ (c : BitVec 1) (wt : Int), 1 < wt →
;   signExtend wt c ^^^ zeroExtend wt c = ite(c = 1, -2#wt, 0#wt)
; (c=0: 0^^^0=0; c=1: -1^^^1=-2)
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(assert (< 1 wt))
(assert (not (=
  (bvxor (psign_extend (- wt 1) c) (pzero_extend (- wt 1) c))
  (ite (= c (int_to_pbv 1 1))
       (bvsub (int_to_pbv wt 0) (int_to_pbv wt 2))
       (int_to_pbv wt 0))
)))
(check-sat)
