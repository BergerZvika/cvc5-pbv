(set-logic QF_BV)
(declare-const w1 Int) ; 8
(declare-const w2 Int) ; 32
(declare-const x (_ BitVec w2))
(assert (<= w1 w2))
(assert (= (bvand (psign_extend w2 (pextract 0 (- w1 1) x)) (pzero_extend w2 (int_to_pbv w1 -1))) (bvand x (pzero_extend w2 (int_to_pbv w1 -1)))))
(check-sat)

; ∀ (x : BitVec 32), signExtend 32 (truncate 8 x) &&& 255#32 = x &&& 255#32
