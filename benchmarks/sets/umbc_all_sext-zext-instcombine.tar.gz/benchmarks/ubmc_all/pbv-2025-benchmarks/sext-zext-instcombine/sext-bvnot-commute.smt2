; ∀ (x : BitVec wa) (wt : Int), wa < wt →
;   signExtend wt (bvnot x) = bvnot (signExtend wt x)
; (flipping bits then extending = extending then flipping all bits)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (psign_extend (- wt wa) (bvnot x))
  (bvnot (psign_extend (- wt wa) x))
)))
(check-sat)
