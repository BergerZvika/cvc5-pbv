; forall (x : BitVec wa), wa <= wt ->
;   truncate wa (signExtend wt x) = x
; From: trunc_sext_self_thm: truncating a sign-extended value recovers the original
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x  (_ BitVec wa))
(assert (<= wa wt))
(assert (not (=
  (pextract 0 (- wa 1) (psign_extend (- wt wa) x))
  x
)))
(check-sat)
