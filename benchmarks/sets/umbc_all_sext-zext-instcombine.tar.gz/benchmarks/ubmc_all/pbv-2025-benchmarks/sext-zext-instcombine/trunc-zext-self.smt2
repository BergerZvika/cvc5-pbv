; forall (x : BitVec wa), wa <= wt ->
;   truncate wa (zeroExtend wt x) = x
; From: trunc_zext_self_thm: truncating a zero-extended value recovers the original
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x  (_ BitVec wa))
(assert (<= wa wt))
(assert (not (=
  (pextract 0 (- wa 1) (pzero_extend (- wt wa) x))
  x
)))
(check-sat)
