(set-logic QF_BV)
(declare-const w1 Int) ; 1
(declare-const w2 Int) ; 32
(declare-const x (_ BitVec w1))
(assert (<= (+ w1 1) w2))
(assert (bvslt (pzero_extend (- w2 w1) x) (int_to_pbv w2 -1)))
(check-sat)


; ∀ (x : BitVec 1), ofBool (zeroExtend 32 x <ₛ -1#32) = 0#1
