; test_sext_thm.extracted_1._1 (generalized)
; ∀ (x : BitVec w) (wt : Int), w < wt →
;   signExtend wt x + signExtend wt (ofBool (x == 0)) ^^^ -1
;   = signExtend wt (ofBool (x != 0)) - signExtend wt x
(set-logic ALL)
(declare-const w Int)
(declare-const wt Int)
(declare-const x (_ BitVec w))
(assert (< w wt))
(assert (not (=
  (bvxor
    (bvadd (psign_extend (- wt w) x)
           (psign_extend (- wt 1) (ite (= x (int_to_pbv w 0)) (int_to_pbv 1 1) (int_to_pbv 1 0))))
    (bvnot (int_to_pbv wt 0)))
  (bvsub
    (psign_extend (- wt 1) (ite (= x (int_to_pbv w 0)) (int_to_pbv 1 0) (int_to_pbv 1 1)))
    (psign_extend (- wt w) x))
)))
(check-sat)
