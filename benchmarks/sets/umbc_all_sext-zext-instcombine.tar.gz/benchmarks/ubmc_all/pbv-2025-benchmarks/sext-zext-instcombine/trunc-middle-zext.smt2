; test17_thm (truncate of wider zext)
; ∀ (x : BitVec wa) (wm wt : Int), wa < wm → wm < wt →
;   truncate wm (zeroExtend wt x) = zeroExtend wm x
(set-logic ALL)
(declare-const wa Int)
(declare-const wm Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(assert (< wa wm))
(assert (< wm wt))
(assert (not (=
  (pextract 0 (- wm 1) (pzero_extend (- wt wa) x))
  (pzero_extend (- wm wa) x)
)))
(check-sat)
