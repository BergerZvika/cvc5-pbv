; ∀ (x y : BitVec wa) (wt : Int), wa < wt →
;   signExtend wt x ^^^ signExtend wt y = signExtend wt (x ^^^ y)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(declare-const y (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (bvxor (psign_extend (- wt wa) x) (psign_extend (- wt wa) y))
  (psign_extend (- wt wa) (bvxor x y))
)))
(check-sat)
