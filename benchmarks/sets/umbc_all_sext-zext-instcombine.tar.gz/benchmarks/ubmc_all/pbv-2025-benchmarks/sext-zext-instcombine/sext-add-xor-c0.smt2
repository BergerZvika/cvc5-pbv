; t0_thm.extracted_1._2
; ∀ (x : BitVec wt) (c : BitVec 1) (wt : Int), 1 < wt → c ≠ 1 →
;   signExtend wt c + x ^^^ signExtend wt c = x
; (sext(0) = 0; 0 + x = x; x ^^^ 0 = x)
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(declare-const x (_ BitVec wt))
(assert (< 1 wt))
(assert (not (= c (int_to_pbv 1 1))))
(assert (not (=
  (bvxor (bvadd (psign_extend (- wt 1) c) x) (psign_extend (- wt 1) c))
  x
)))
(check-sat)
