; ∀ (x : BitVec wt) (wa wm : Int), wa < wm → wm < wt →
;   truncate wa (zeroExtend wt (truncate wm x)) = truncate wa x
(set-logic ALL)
(declare-const wa Int)
(declare-const wm Int)
(declare-const wt Int)
(declare-const x (_ BitVec wt))
(assert (< wa wm))
(assert (< wm wt))
(assert (not (=
  (pextract 0 (- wa 1) (pzero_extend (- wt wm) (pextract 0 (- wm 1) x)))
  (pextract 0 (- wa 1) x)
)))
(check-sat)
