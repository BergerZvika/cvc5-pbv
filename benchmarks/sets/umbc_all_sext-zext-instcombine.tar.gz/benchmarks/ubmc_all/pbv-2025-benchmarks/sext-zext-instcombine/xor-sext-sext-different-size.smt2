; ∀ (x : BitVec wb) (y : BitVec wa), wa < wb → wb < wt →
;   signExtend wt x ^^^ signExtend wt y = signExtend wt (x ^^^ signExtend wb y)
; Analogous to and_sext_sext and or_sext_sext
(set-logic ALL)
(declare-const wa Int)
(declare-const wb Int)
(declare-const wt Int)
(declare-const x (_ BitVec wb))
(declare-const y (_ BitVec wa))
(assert (< wa wb))
(assert (< wb wt))
(assert (not (=
  (bvxor (psign_extend (- wt wb) x) (psign_extend (- wt wa) y))
  (psign_extend (- wt wb) (bvxor x (psign_extend (- wb wa) y)))
)))
(check-sat)
