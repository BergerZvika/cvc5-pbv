; forall (x y : BitVec wa), wa < wt ->
;   signExtend wt x ||| signExtend wt y = signExtend wt (x ||| y)
; From: or_sext_sext_same_width_thm: OR distributes into sext for same-width operands
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x  (_ BitVec wa))
(declare-const y  (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (bvor (psign_extend (- wt wa) x) (psign_extend (- wt wa) y))
  (psign_extend (- wt wa) (bvor x y))
)))
(check-sat)
