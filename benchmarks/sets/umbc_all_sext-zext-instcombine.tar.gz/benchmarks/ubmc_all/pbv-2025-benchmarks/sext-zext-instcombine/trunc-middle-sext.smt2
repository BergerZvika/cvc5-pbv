; test18_thm (truncate of wider sext)
; ∀ (x : BitVec wa) (wm wt : Int), wa < wm → wm < wt →
;   truncate wm (signExtend wt x) = signExtend wm x
(set-logic ALL)
(declare-const wa Int)
(declare-const wm Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(assert (< wa wm))
(assert (< wm wt))
(assert (not (=
  (pextract 0 (- wm 1) (psign_extend (- wt wa) x))
  (psign_extend (- wm wa) x)
)))
(check-sat)
