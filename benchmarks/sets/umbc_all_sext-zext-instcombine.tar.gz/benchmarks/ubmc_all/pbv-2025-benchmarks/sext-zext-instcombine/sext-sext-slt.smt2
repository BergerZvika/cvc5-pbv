; ∀ (x x1 : BitVec w) (wt : Int), w < wt →
;   ofBool (signExtend wt x1 <ₛ signExtend wt x) = ofBool (x1 <ₛ x)
; From: sext_sext_slt_thm (x x_1 : BitVec 8), concrete wt=32
(set-logic ALL)
(declare-const w  Int)
(declare-const wt Int)
(declare-const x  (_ BitVec w))
(declare-const x1 (_ BitVec w))
(assert (< w wt))
(assert (not (=
  (ite (bvslt (psign_extend (- wt w) x1) (psign_extend (- wt w) x)) (int_to_pbv 1 1) (int_to_pbv 1 0))
  (ite (bvslt x1 x)                                                   (int_to_pbv 1 1) (int_to_pbv 1 0))
)))
(check-sat)
