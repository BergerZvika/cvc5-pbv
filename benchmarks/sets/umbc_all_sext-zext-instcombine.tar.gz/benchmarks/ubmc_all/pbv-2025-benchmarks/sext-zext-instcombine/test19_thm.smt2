(set-logic QF_BV)
(declare-const w1 Int) ; 32
(declare-const w2 Int) ; 64
(declare-const x (_ BitVec w1))
(declare-const y (_ BitVec w1))
(assert (<= w1 w2))
(assert (not (= (bvsle (psign_extend (- w2 w1) x) (psign_extend (- w2 w1) y)) (bvsle x y))))
(check-sat)

; ∀ (x : BitVec 32), ofBool (signExtend 64 x <ₛ 12345#64) = ofBool (x <ₛ 12345#32)

