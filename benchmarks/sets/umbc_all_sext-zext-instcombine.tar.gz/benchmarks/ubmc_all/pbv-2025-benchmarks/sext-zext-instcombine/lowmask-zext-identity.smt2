; ∀ (x : BitVec wa) (wt : Int), wa < wt →
;   zeroExtend wt x &&& lowmask(wa,wt) = zeroExtend wt x
; (zext has 0 in high bits, AND with lowmask leaves them 0, low bits unchanged)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (bvand (pzero_extend (- wt wa) x) (pzero_extend (- wt wa) (bvnot (int_to_pbv wa 0))))
  (pzero_extend (- wt wa) x)
)))
(check-sat)
