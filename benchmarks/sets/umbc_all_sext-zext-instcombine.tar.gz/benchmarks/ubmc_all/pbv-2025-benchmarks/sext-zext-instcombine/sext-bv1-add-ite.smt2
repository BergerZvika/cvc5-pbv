; ∀ (c : BitVec 1) (x : BitVec wt) (wt : Int), 1 < wt →
;   signExtend wt c + x = ite(c = 1, x - 1, x)
; (sext(0)=0; 0+x=x; sext(1)=-1; -1+x=x-1)
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(declare-const x (_ BitVec wt))
(assert (< 1 wt))
(assert (not (=
  (bvadd (psign_extend (- wt 1) c) x)
  (ite (= c (int_to_pbv 1 1)) (bvsub x (int_to_pbv wt 1)) x)
)))
(check-sat)
