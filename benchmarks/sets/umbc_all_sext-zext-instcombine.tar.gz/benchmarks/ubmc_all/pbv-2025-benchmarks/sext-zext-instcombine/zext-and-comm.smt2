; forall (x : BitVec wa) (y : BitVec wt), wa < wt ->
;   zeroExtend wt x &&& y = y &&& zeroExtend wt x
; From: zext_and_comm_thm: AND is commutative (via zext)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x  (_ BitVec wa))
(declare-const y  (_ BitVec wt))
(assert (< wa wt))
(assert (not (=
  (bvand (pzero_extend (- wt wa) x) y)
  (bvand y (pzero_extend (- wt wa) x))
)))
(check-sat)
