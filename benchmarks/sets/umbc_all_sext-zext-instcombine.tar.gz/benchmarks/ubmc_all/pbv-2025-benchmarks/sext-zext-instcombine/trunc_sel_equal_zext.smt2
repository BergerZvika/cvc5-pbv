; define i32 @trunc_sel_equal_zext(i32 %a, i1 %cmp) {
; ; CHECK-LABEL: @trunc_sel_equal_zext(
; ; CHECK-NEXT:    [[TMP1:%.*]] = and i32 [[A:%.*]], 65535
; ; CHECK-NEXT:    [[EXT:%.*]] = select i1 [[CMP:%.*]], i32 [[TMP1]], i32 42
; ; CHECK-NEXT:    ret i32 [[EXT]]
; ;
;   %trunc = trunc i32 %a to i16
;   %sel = select i1 %cmp, i16 %trunc, i16 42
;   %ext = zext i16 %sel to i32
;   ret i32 %ext
; }

(set-logic ALL)
(declare-const w1 Int)
(declare-const w2 Int)
(declare-const cmp (_ BitVec 1))
(declare-const a (_ BitVec w2))
(declare-const b (_ BitVec w1))
(assert (< w1 w2))
(assert
	(distinct
		(pzero_extend (- w2 w1) (ite (= cmp (int_to_pbv 1 1)) (pextract 0 (- w1 1) a) b))
		(ite
			(= cmp (int_to_pbv 1 1))
			(bvand a (pzero_extend (- w2 w1) (int_to_pbv w1 -1)))
			(pzero_extend (- w2 w1) b))))
(check-sat)
