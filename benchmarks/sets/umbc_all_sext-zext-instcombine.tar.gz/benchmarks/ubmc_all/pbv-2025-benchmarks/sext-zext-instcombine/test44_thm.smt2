(set-logic QF_BV)
(declare-const w1 Int) ; 8
(declare-const w2 Int) ; 16
(declare-const x (_ BitVec w1))
(declare-const K (_ BitVec w2))
(assert (<= w1 w2))
(assert (bvult K (bvshl (int_to_pbv w2 1) (int_to_pbv w2 (- w2 1)))))
(assert (not (= (int_to_pbv w2 0) 
  (bvand (bvshl (int_to_pbv w2 1) (int_to_pbv w2 (- w2 1))) (bvor (pzero_extend (- w2 w1) x) K)))))
(check-sat)

; ∀ (x : BitVec 8), Not (zeroExtend 16 x ||| 1234#16).msb 
