; ∀ (x y : BitVec wa) (wt : Int), wa < wt →
;   truncate wa (zeroExtend wt x + signExtend wt y) = x + y
; (low bits of zext x = x, low bits of sext y = y; add low bits = x+y)
(set-logic ALL)
(declare-const wa Int)
(declare-const wt Int)
(declare-const x (_ BitVec wa))
(declare-const y (_ BitVec wa))
(assert (< wa wt))
(assert (not (=
  (pextract 0 (- wa 1) (bvadd (pzero_extend (- wt wa) x) (psign_extend (- wt wa) y)))
  (bvadd x y)
)))
(check-sat)
