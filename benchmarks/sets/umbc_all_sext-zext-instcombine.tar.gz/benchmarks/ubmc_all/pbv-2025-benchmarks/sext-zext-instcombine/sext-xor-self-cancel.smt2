; ∀ (c : BitVec 1) (x : BitVec wt) (wt : Int), 1 < wt →
;   signExtend wt c ^^^ x ^^^ signExtend wt c = x
; (XOR is its own inverse: a ^^^ b ^^^ a = b)
(set-logic ALL)
(declare-const wt Int)
(declare-const c (_ BitVec 1))
(declare-const x (_ BitVec wt))
(assert (< 1 wt))
(assert (not (=
  (bvxor (bvxor (psign_extend (- wt 1) c) x) (psign_extend (- wt 1) c))
  x
)))
(check-sat)
