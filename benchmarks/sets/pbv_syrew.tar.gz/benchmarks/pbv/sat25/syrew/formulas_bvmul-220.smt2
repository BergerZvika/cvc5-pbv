(set-logic PBV)
(declare-fun s () PBitVec)
(assert (distinct (distinct (int_to_pbv (pbvsize s) 0) (pbvmul s (pbvmul s s))) (distinct (int_to_pbv (pbvsize s) 0) (pbvmul s s))))
(check-sat)
