(set-logic PBV)
(declare-fun s () PBitVec)
(assert (distinct (distinct s (pbvshl s (pbvurem (int_to_pbv (pbvsize s) 1) s))) (pbvult (int_to_pbv (pbvsize s) 1) s)))
(check-sat)
