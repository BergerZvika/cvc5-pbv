; {
;   "name": "sum_same",
;   "preconditions": [],
;   "lhs": "(bw q (+ (bw p a) (bw p a)))",
;   "rhs": "(bw q (* (bw 2 2) (bw p a)))"
; }
; a + a = 2 * a. Ring identity at width q.
(set-logic ALL)
(declare-const p Int)
(declare-const q Int)

;; --- END PREAMBLE ---

(declare-const a (_ BitVec p))

(assert (>= q p))
(assert (not (=
  (bvadd (pzero_extend (- q p) a) (pzero_extend (- q p) a))
  (bvmul (int_to_pbv q 2) (pzero_extend (- q p) a))
)))
(check-sat)
