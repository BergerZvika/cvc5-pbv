; {
;   "name": "commutativity_mult",
;   "preconditions": [],
;   "lhs": "(bw r ( * (bw p a) (bw q b)))",
;   "rhs": "(bw r ( * (bw q b) (bw p a)))"
; }
; Commutativity of multiplication at width r.
(set-logic ALL)
(declare-const p Int)
(declare-const q Int)
(declare-const r Int)

;; --- END PREAMBLE ---

(declare-const a (_ BitVec p))
(declare-const b (_ BitVec q))

(assert (>= r p))
(assert (>= r q))
(assert (not (=
  (bvmul (pzero_extend (- r p) a) (pzero_extend (- r q) b))
  (bvmul (pzero_extend (- r q) b) (pzero_extend (- r p) a))
)))
(check-sat)
