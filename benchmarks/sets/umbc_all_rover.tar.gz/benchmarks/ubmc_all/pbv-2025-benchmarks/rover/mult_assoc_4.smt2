; {
;   "name": "mult_assoc_4",
;   "preconditions": ["(<= (+ r s) q)", "(<= (+ p r) u)"],
;   "lhs": "(bw t ( * (bw u (* (bw p a) (bw r b))) (bw s c)))",
;   "rhs": "(bw t ( * (bw p a) (bw q (* (bw r b) (bw s c)))))"
; }
; Associativity of multiplication at width t. Holds in ring Z/2^t.
(set-logic ALL)
(declare-const p Int)
(declare-const q Int)
(declare-const r Int)
(declare-const s Int)
(declare-const t Int)
(declare-const u Int)

;; --- END PREAMBLE ---

(declare-const a (_ BitVec p))
(declare-const b (_ BitVec r))
(declare-const c (_ BitVec s))

(assert (<= (+ r s) q))
(assert (<= (+ p r) u))
(assert (>= t p))
(assert (>= t r))
(assert (>= t s))
(assert (not (=
  (bvmul (bvmul (pzero_extend (- t p) a) (pzero_extend (- t r) b)) (pzero_extend (- t s) c))
  (bvmul (pzero_extend (- t p) a) (bvmul (pzero_extend (- t r) b) (pzero_extend (- t s) c)))
)))
(check-sat)
