; {
;   "name": "mult_sum_same",
;   "preconditions": ["(> t p)", "(> t 1)", "(>= s (+ p q))"],
;   "lhs": "(bw r (+ (bw s (* (bw p a) (bw q b))) (bw q b)))",
;   "rhs": "(bw r (* (bw t (+ (bw p a) (bw 1 1))) (bw q b)))"
; }
; a*b + b = (a+1)*b. Ring identity at width r.
(set-logic ALL)
(declare-const p Int)
(declare-const q Int)
(declare-const r Int)
(declare-const s Int)
(declare-const t Int)

;; --- END PREAMBLE ---

(declare-const a (_ BitVec p))
(declare-const b (_ BitVec q))

(assert (> t p))
(assert (> t 1))
(assert (>= s (+ p q)))
(assert (>= r p))
(assert (>= r q))
(assert (not (=
  ; LHS: a*b + b at width r
  (bvadd (bvmul (pzero_extend (- r p) a) (pzero_extend (- r q) b)) (pzero_extend (- r q) b))
  ; RHS: (a+1)*b at width r
  (bvmul (bvadd (pzero_extend (- r p) a) (int_to_pbv r 1)) (pzero_extend (- r q) b))
)))
(check-sat)
