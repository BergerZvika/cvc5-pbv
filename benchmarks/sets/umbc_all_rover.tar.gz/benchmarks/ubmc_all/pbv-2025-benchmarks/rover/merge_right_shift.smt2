; {
;   "name": "merge_right_shift",
;   "preconditions": ["(>= u p)", "(> t s)", "(> t q)"],
;   "lhs": "(bw r (>> (bw u (>> (bw p a) (bw q b))) (bw s c)))",
;   "rhs": "(bw r (>> (bw p a) (bw t (+ (bw q b) (bw s c)))))"
; }
; (a >> b) >> c = a >> (b + c), when b + c doesn't overflow at width t.
; t > q, t > s guarantee no overflow. Computed at width w = max(p, t).
(set-logic ALL)
(declare-const p Int)
(declare-const q Int)
(declare-const r Int)
(declare-const s Int)
(declare-const t Int)
(declare-const u Int)

; w = max(p, t), a common width for computing both sides
(declare-const w Int)
(assert (or (= w p) (= w t)))
(assert (>= w p))
(assert (>= w t))

;; --- END PREAMBLE ---

(declare-const a (_ BitVec p))
(declare-const b (_ BitVec q))
(declare-const c (_ BitVec s))

(assert (>= u p))
(assert (> t s))
(assert (> t q))
(assert (not (=
  ; LHS: (a >> b) >> c at width w
  (bvlshr (bvlshr (pzero_extend (- w p) a) (pzero_extend (- w q) b)) (pzero_extend (- w s) c))
  ; RHS: a >> (b + c) at width w, where b + c computed at width t
  (bvlshr (pzero_extend (- w p) a) (pzero_extend (- w t) (bvadd (pzero_extend (- t q) b) (pzero_extend (- t s) c))))
)))
(check-sat)
