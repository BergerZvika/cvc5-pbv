; {
;   "name": "sub_to_neg",
;   "preconditions": [],
;   "lhs": "(bw r (- (bw p a) (bw q b)))",
;   "rhs": "(bw r (+ (bw p a) (- (bw q b))))"
; }
(set-logic QF_BV)
(declare-const p Int)
(declare-const q Int)
(declare-const r Int)

(declare-const pq1 Int)
(assert (or (= pq1 (+ p 1)) (= pq1 (+ q 1))))
(assert (>= pq1 (+ p 1)))
(assert (>= pq1 (+ q 1)))

;; --- END PREAMBLE ---

(declare-const a (_ BitVec p))
(declare-const b (_ BitVec q))

(assert (not (=
  (pzero_extend r (bvsub (pzero_extend (- pq1 p) a) (pzero_extend (- pq1 q) b)))
  (pzero_extend r (bvadd (pzero_extend (- pq1 p) a) (bvneg (pzero_extend (- pq1 q) b))))
)))

(check-sat)
