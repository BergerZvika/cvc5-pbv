; {
;   "name": "dist_over_add",
;   "preconditions": ["(>= q r)", "(>= u r)", "(>= v r)"],
;   "lhs": "(bw r (* (bw p a) (+ (bw s b) (bw t c))))",
;   "rhs": "(bw r (+ (bw u (* (bw p a) (bw s b))) (bw v (* (bw p a) (bw t c)) ) ))"
; }
; Distributive law: a*(b+c) = a*b + a*c. Holds in ring Z/2^r.
(set-logic ALL)
(declare-const p Int)
(declare-const q Int)
(declare-const r Int)
(declare-const s Int)
(declare-const t Int)
(declare-const u Int)
(declare-const v Int)

;; --- END PREAMBLE ---

(declare-const a (_ BitVec p))
(declare-const b (_ BitVec s))
(declare-const c (_ BitVec t))

(assert (>= q r))
(assert (>= u r))
(assert (>= v r))
(assert (>= r p))
(assert (>= r s))
(assert (>= r t))
(assert (not (=
  ; LHS: a * (b + c) at width r
  (bvmul (pzero_extend (- r p) a) (bvadd (pzero_extend (- r s) b) (pzero_extend (- r t) c)))
  ; RHS: a*b + a*c at width r
  (bvadd (bvmul (pzero_extend (- r p) a) (pzero_extend (- r s) b)) (bvmul (pzero_extend (- r p) a) (pzero_extend (- r t) c)))
)))
(check-sat)
