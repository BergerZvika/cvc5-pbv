; {
;   "name": "add_assoc_1",
;   "preconditions": ["(>= q t)", "(>= u t)"],
;   "lhs": "(bw t ( + (bw u (+ (bw p a) (bw r b))) (bw s c)))",
;   "rhs": "(bw t ( + (bw p a) (bw q (+ (bw r b) (bw s c)))))"
; }
; Since u >= t and q >= t, both sides reduce to (a + b + c) mod 2^t.
; We encode at width t directly, requiring t >= p, r, s for zero-extension.
(set-logic ALL)
(declare-const p Int)
(declare-const q Int)
(declare-const r Int)
(declare-const s Int)
(declare-const t Int)
(declare-const u Int)

;; --- END PREAMBLE ---

(declare-const a (_ BitVec p))
(declare-const b (_ BitVec r))
(declare-const c (_ BitVec s))

(assert (>= q t))
(assert (>= u t))
(assert (>= t p))
(assert (>= t r))
(assert (>= t s))
(assert (not (=
  (bvadd (bvadd (pzero_extend (- t p) a) (pzero_extend (- t r) b)) (pzero_extend (- t s) c))
  (bvadd (pzero_extend (- t p) a) (bvadd (pzero_extend (- t r) b) (pzero_extend (- t s) c)))
)))
(check-sat)
