; {
;   "name": "mul_one",
;   "preconditions": [],
;   "lhs": "(bw p (* (bw p a) (bw q 1)))",
;   "rhs": "(bw p a)"
; }
; a * 1 = a at width p. Trivially true.
(set-logic ALL)
(declare-const p Int)
(declare-const q Int)

;; --- END PREAMBLE ---

(declare-const a (_ BitVec p))

(assert (not (=
  (bvmul a (int_to_pbv p 1))
  a
)))
(check-sat)
