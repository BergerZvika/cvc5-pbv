; {
;   "name": "add_assoc_2",
;   "preconditions": ["(< r q)", "(< s q)", "(>= u t)"],
;   "lhs": "(bw t ( + (bw u (+ (bw p a) (bw r b))) (bw s c)))",
;   "rhs": "(bw t ( + (bw p a) (bw q (+ (bw r b) (bw s c)))))"
; }
; With r < q, s < q: b+c doesn't overflow at width q, so bw_q(b+c)=b+c.
; With u >= t: bw_t(bw_u(x))=bw_t(x). Both sides reduce to bw_t(a+b+c).
(set-logic ALL)
(declare-const p Int)
(declare-const q Int)
(declare-const r Int)
(declare-const s Int)
(declare-const t Int)
(declare-const u Int)

;; --- END PREAMBLE ---

(declare-const a (_ BitVec p))
(declare-const b (_ BitVec r))
(declare-const c (_ BitVec s))

(assert (< r q))
(assert (< s q))
(assert (>= u t))
(assert (>= t p))
(assert (>= t r))
(assert (>= t s))
(assert (not (=
  (bvadd (bvadd (pzero_extend (- t p) a) (pzero_extend (- t r) b)) (pzero_extend (- t s) c))
  (bvadd (pzero_extend (- t p) a) (bvadd (pzero_extend (- t r) b) (pzero_extend (- t s) c)))
)))
(check-sat)
