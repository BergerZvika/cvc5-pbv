(set-logic PBV)

(declare-const x PBitVec)
(declare-const s PBitVec)
(declare-const t PBitVec)
(define-fun lemma_UREM_REF6 ((x PBitVec) (s PBitVec) (t PBitVec)) Bool (pbvuge (pbvnot (pbvneg s)) t))
(assert (= t (pbvurem x s)))
(assert (not (lemma_UREM_REF6 x s t)))
(check-sat)
