(set-logic PBV)

(declare-const x PBitVec)
(declare-const s PBitVec)
(declare-const t PBitVec)
(define-fun lemma_UDIV_REF5 ((x PBitVec) (s PBitVec) (t PBitVec)) Bool (=> (distinct s (int_to_pbv (pbvsize x) 0)) (pbvule t x)))
(assert (= t (pbvudiv x s)))
(assert (not (lemma_UDIV_REF5 x s t)))
(check-sat)
