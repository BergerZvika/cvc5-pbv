(set-logic PBV)

(declare-const x PBitVec)
(declare-const s PBitVec)
(declare-const t PBitVec)
(define-fun lemma_UREM_REF1 ((x PBitVec) (s PBitVec) (t PBitVec)) Bool (=> (distinct s (int_to_pbv (pbvsize x) 0)) (pbvule t s)))
(assert (= t (pbvurem x s)))
(assert (not (lemma_UREM_REF1 x s t)))
(check-sat)
