(set-logic PBV)

(declare-const x PBitVec)
(declare-const s PBitVec)
(declare-const t PBitVec)
(define-fun lemma_UDIV_REF23 ((x PBitVec) (s PBitVec) (t PBitVec)) Bool (pbvuge t (pbvlshr (pbvshl x (int_to_pbv (pbvsize x) 1)) s)))
(assert (= t (pbvudiv x s)))
(assert (not (lemma_UDIV_REF23 x s t)))
(check-sat)
