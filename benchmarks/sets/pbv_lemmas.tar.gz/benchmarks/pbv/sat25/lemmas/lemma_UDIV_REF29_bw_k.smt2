(set-logic PBV)

(declare-const x PBitVec)
(declare-const s PBitVec)
(declare-const t PBitVec)
(define-fun lemma_UDIV_REF29 ((x PBitVec) (s PBitVec) (t PBitVec)) Bool (pbvuge x (pbvshl t (pbvnot (pbvxor x s)))))
(assert (= t (pbvudiv x s)))
(assert (not (lemma_UDIV_REF29 x s t)))
(check-sat)
