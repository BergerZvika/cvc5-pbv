(set-logic PBV)

(declare-const x PBitVec)
(declare-const s PBitVec)
(declare-const t PBitVec)
(define-fun lemma_UDIV_REF7 ((x PBitVec) (s PBitVec) (t PBitVec)) Bool (pbvuge x (pbvneg (pbvand (pbvneg s) (pbvneg t)))))
(assert (= t (pbvudiv x s)))
(assert (not (lemma_UDIV_REF7 x s t)))
(check-sat)
