(set-logic PBV)

(declare-const x PBitVec)
(declare-const s PBitVec)
(declare-const t PBitVec)
(define-fun lemma_UREM_REF11 ((x PBitVec) (s PBitVec) (t PBitVec)) Bool (pbvuge (pbvand t (pbvor x s)) (pbvand t (int_to_pbv (pbvsize x) 1))))
(assert (= t (pbvurem x s)))
(assert (not (lemma_UREM_REF11 x s t)))
(check-sat)
