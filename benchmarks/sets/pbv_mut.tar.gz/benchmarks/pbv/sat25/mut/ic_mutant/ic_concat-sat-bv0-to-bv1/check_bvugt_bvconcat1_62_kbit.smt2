(set-logic PBV)

(declare-fun s () PBitVec)
(declare-fun tx () PBitVec)
(declare-fun ts () PBitVec)

(define-fun min () PBitVec
  (pbvnot (pbvlshr (pbvnot (int_to_pbv (pbvsize tx) 1)) (int_to_pbv (pbvsize tx) 1)))
)
(define-fun max () PBitVec
  (pbvnot min)
)

(define-fun SC () Bool
(and (pbvuge s ts) (=> (= s ts) (distinct tx (pbvnot (int_to_pbv (pbvsize tx) 0)))))
)

(assert
 (not
  (and
   (=> SC (exists ((x PBitVec)) (pbvugt (pconcat s x) (pconcat ts tx))))
   (=> (exists ((x PBitVec)) (pbvugt (pconcat s x) (pconcat ts tx))) SC)
  )
 )
)
(check-sat)
