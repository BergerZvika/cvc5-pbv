(set-logic PBV)

(declare-fun s () PBitVec)
(declare-fun tx () PBitVec)
(declare-fun ts () PBitVec)

(define-fun min () PBitVec
  (pbvnot (pbvlshr (pbvnot (int_to_pbv (pbvsize s) 0)) (int_to_pbv (pbvsize s) 0)))
)
(define-fun max () PBitVec
  (pbvnot min)
)

(define-fun SC () Bool
(pbvsge s ts)
)

(assert
 (not
  (and
   (=> SC (exists ((x PBitVec)) (pbvsge (pconcat s x) (pconcat ts tx))))
   (=> (exists ((x PBitVec)) (pbvsge (pconcat s x) (pconcat ts tx))) SC)
  )
 )
)
(check-sat)
